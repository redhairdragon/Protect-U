# NFC Beam
![](file/nfc-beam.png)
![](file/nfc-beam-words.png)
![](file/nfc-beam-calc.png)
