package com.pgzxc.nfcbeam;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.NfcEvent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

import org.json.*;

import static android.nfc.NdefRecord.createExternal;
import static android.nfc.NfcAdapter.getDefaultAdapter;


public class MainActivity extends AppCompatActivity implements
        NfcAdapter.CreateNdefMessageCallback, NfcAdapter.OnNdefPushCompleteCallback {

    private NfcAdapter mNfcAdapter;
    private PendingIntent mPendingIntent;
    private scannedIdEntry idEntry=new scannedIdEntry();
    boolean registered=false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mNfcAdapter = getDefaultAdapter(this);
        mPendingIntent = PendingIntent.getActivity(this, 0, new Intent(this,
                getClass()), 0);
        mNfcAdapter.setNdefPushMessageCallback(this, this);
        mNfcAdapter.setOnNdefPushCompleteCallback(this, this);


    }

    @Override
    public void onNdefPushComplete(NfcEvent event) {
        Log.d("message", "complete");
    }

    @Override
    public NdefMessage createNdefMessage(NfcEvent event) {
        try{
            byte[] data=idEntry.generateJsonStr().getBytes("UTF-8");
            NdefRecord record=createExternal ("shen.com","json",data);
            NdefMessage ndefMessage = new NdefMessage(record);
            return ndefMessage;
        }
        catch (UnsupportedEncodingException ignored){ }
        return null;

    }

    @Override
    public void onResume() {
        super.onResume();
        if (mNfcAdapter != null)
            mNfcAdapter.enableForegroundDispatch(this, mPendingIntent, null,
                    null);

    }

    @Override
    public void onPause() {
        super.onPause();
        if (mNfcAdapter != null)
            mNfcAdapter.disableForegroundDispatch(this);
    }

    @Override
    public void onNewIntent(Intent intent) {
        processIntent(intent);
    }

    void processIntent(Intent intent) {
        Parcelable[] rawMsgs = intent
                .getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES);
        NdefMessage msg = (NdefMessage) rawMsgs[0];
        try {
            String jsonStr=new String(msg.getRecords()[0].getPayload(),"UTF-8");
            Toast.makeText(this,jsonStr , Toast.LENGTH_LONG).show();
        }catch(UnsupportedEncodingException ignored){}
    }

    public void sendHttpReq(View view) {
        HttpTask httpTask=new HttpTask();
        httpTask.execute();
    }

    private class HttpTask extends AsyncTask<String, Integer, String> {
        private String res="233";
        private String argument;
        @Override
        protected String doInBackground(String... params) {

            try {
                String vcode,name;
                EditText edit = findViewById(R.id.vcode_input);
                vcode=edit.getText().toString();
                edit=findViewById(R.id.name_input);
                name=edit.getText().toString();
                JSONObject IdEntry=new JSONObject();
                IdEntry.put("vcode",vcode);
                IdEntry.put("name",name);
                argument=IdEntry.toString();
                String urlStr="http://protected-u.appspot.com/verifyuser?data="+URLEncoder.encode(argument, "UTF-8");
                Log.d("myTag", "doInBackground: "+urlStr);
                URL url = new URL(urlStr);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.connect();
                conn.setConnectTimeout(6*1000);
                conn.setReadTimeout(6 * 1000);
                InputStream in = conn.getInputStream();
                res=readStream(in);
                conn.disconnect();
                return new String(res);
            } catch (MalformedURLException ignore) {
                Log.d("myTag", "doInBackground:Happened ");
            } catch (IOException ignore) {
                Log.d("myTag", "doInBackground: Happened2"+ignore.toString());
            } catch(JSONException ex){
                Log.d("myTag", "doInBackground: Happened3");
            }
            return null;
        }

        //onPostExecute方法用于在执行完后台任务后更新UI,显示结果
        @Override
        protected void onPostExecute(String result) {
            TextView textView = findViewById(R.id.http_res);
            textView.setText(res);
            try{
                JSONObject jsonObj = new JSONObject(res);
                String jResult= jsonObj.getString("result");
                if(jResult.equals("true")){
                    idEntry.primaryKey=jsonObj.getString("primaryKey");
                    idEntry.salt=jsonObj.getString("salt");
                    idEntry.studentId=jsonObj.getString("studnetID");
                    String display="Id: "+jsonObj.getString("studnetID")+"\n";
                    Log.d("myTag", idEntry.generateJsonStr());
                    Log.d("myTag", idEntry.salt);
                    textView.setText(display);
                    registered=true;
                }
                else{
                    textView.setText("Authentication Failed.");
                }
            }
            catch (JSONException ignore){Log.d("myTag", "doInBackground: Happened5 "+ignore.toString());}
        }
        // Converting InputStream to String
        private String readStream(InputStream in) {
            BufferedReader reader = null;
            StringBuffer response = new StringBuffer();
            try {
                reader = new BufferedReader(new InputStreamReader(in));
                String line = "";
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            return response.toString();
        }


    }

}



